//
//  Juxt_a_poseTests.m
//  Juxt-a-poseTests
//
//  Created by Brandon Phillips on 5/25/13.
//  Copyright (c) 2013 We Are Station. All rights reserved.
//

#import "Juxt_a_poseTests.h"

@implementation Juxt_a_poseTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Juxt-a-poseTests");
}

@end
