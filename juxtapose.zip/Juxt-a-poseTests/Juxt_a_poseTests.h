//
//  Juxt_a_poseTests.h
//  Juxt-a-poseTests
//
//  Created by Brandon Phillips on 5/25/13.
//  Copyright (c) 2013 We Are Station. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Juxt_a_poseTests : SenTestCase

@end
