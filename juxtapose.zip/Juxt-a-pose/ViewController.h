//
//  ViewController.h
//  Juxt-a-pose
//
//  Created by Brandon Phillips on 5/25/13.
//  Copyright (c) 2013 We Are Station. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface ViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>{

    
    /*---------TUTORIAL---------*/
    
    IBOutlet UIButton *addAnother;
    UIImagePickerController *picker;
    IBOutlet UIImageView *saveIt;
    int clickTimes;
    IBOutlet UIView *clickBlink;
    int clickShootTimes;
    IBOutlet UIView *clickShootBlink;
    
    /*----------CAMERA----------*/
    
    //UINavigationController *cameraNav;
    NSData *pngData;
    UIImage * libraryImage;
    IBOutlet UIImageView* overlayView;
    UIImageView * newImage;
    UIImageView* topView;
    IBOutlet UISlider *slider;
    NSString *firstPhoto;
    UIImage *img;
    //UIImageView *rotatedView;
    UIView *realOverlayView;
    UIImage *takenPhoto;
    CGFloat overlayAlpha;
    CGRect bounds;
    NSString *flashStatus;
    int cameraRotation;
    IBOutlet UIImageView *transparent;
    IBOutlet UIImageView *opaque;
    IBOutlet UIView *saveCover;
    IBOutlet UIView *camBG;
    IBOutlet UIView *previewView;
    IBOutlet UIImageView *previewImage;
    __weak IBOutlet UIButton *toggleFlashMode;
    UIImage *imageCopy;
    int cameraSource;
    NSString *uploadPhoto;
    IBOutlet UIButton *tutShoot;
    IBOutlet UIImageView *adjustTran;

    
    /*---------MAIN VIEW--------*/
    
   // UIButton *seeAll;
    
    UIImage *image;
    
    IBOutlet UIImageView *imageView;
    IBOutlet UIImageView *another;
}

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

-(IBAction)ifClicked;
-(IBAction)ifShootClicked;
-(IBAction)home;
-(IBAction)cancelPhoto;
-(IBAction)cameraFlip;
-(IBAction)finished;
-(IBAction)usePhoto;
-(IBAction)seeAll;
-(IBAction)TakePhoto;
-(IBAction)FlashToggle;
-(IBAction)ChooseExisting;
//-(IBAction)photosPage;
-(IBAction)sliderChanged:(id)sender;
-(IBAction)shoot;
-(IBAction)cancelPreview;

@property (nonatomic, retain) IBOutlet UILabel *sliderValue;
@property (nonatomic) BOOL showsCameraControls;

//- (UIImage *)fixOrientation;
@end
