//
//  ViewController.m
//  Juxt-a-pose
//
//  Created by Brandon Phillips on 5/25/13.
//  Copyright (c) 2013 We Are Station. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "SharePhoto.h"
#import "AppDelegate.h"
#import "AllPhotos.h"
#import "PhotoLibrary.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize sliderValue;


-(IBAction)seeAll{
    blendedImage = nil;
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(IBAction)finished{
     [self finishedPressed];
}

- (IBAction)cameraFlip{
    if( [UIImagePickerController isCameraDeviceAvailable: UIImagePickerControllerCameraDeviceFront]){
        if(picker.cameraDevice == UIImagePickerControllerCameraDeviceRear){
            
            picker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
            cameraRotation = 1;
            
        }else{
            picker.cameraDevice = UIImagePickerControllerCameraDeviceRear;
            cameraRotation = 0;
        }
    }
}

- (IBAction)FlashToggle{
   

    UIImagePickerControllerCameraFlashMode flashSet = picker.cameraFlashMode;
    switch(flashSet) {
    
        case UIImagePickerControllerCameraFlashModeOn:
            [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeAuto];
            [[NSUserDefaults standardUserDefaults] setObject:@"flashAuto" forKey:@"flash_mode"];
            [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashAuto.png"] forState:UIControlStateNormal];
            break;
        case UIImagePickerControllerCameraFlashModeAuto:
            [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOff];
            [[NSUserDefaults standardUserDefaults] setObject:@"flashOff" forKey:@"flash_mode"];
            [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOff.png"] forState:UIControlStateNormal];
            break;
        case UIImagePickerControllerCameraFlashModeOff:
            [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOn];
            [[NSUserDefaults standardUserDefaults] setObject:@"flashOn" forKey:@"flash_mode"];
            [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOn.png"] forState:UIControlStateNormal];
            break;
    }
}

- (void) finishedPressed{

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    
    NSDate *date = [[NSDate alloc] init];
    
    NSString *formattedDateString = [dateFormatter stringFromDate:date];
    pngData = UIImageJPEGRepresentation(blendedImage, 1.0);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0]; //Get the docs directory
    NSString *fileName = [NSString stringWithFormat:@"image_%@.jpg", formattedDateString];
    NSString *filePath = [documentsPath stringByAppendingPathComponent:fileName]; //Add the file name
    [pngData writeToFile:filePath atomically:YES]; //Write the file
    NSString *urlString = [[NSString alloc] initWithFormat:@"file://%@", filePath];
    SharePhoto *share = [[SharePhoto alloc] initWithNibName:@"SharePhoto" bundle:nil];
    share.blendedImageURL = urlString;
    share.blendedImageName = fileName;
    [self presentViewController:share animated:YES completion:NULL];
}

- (IBAction)sliderChanged:(id)sender {
    slider = (UISlider *)sender;
    adjustTran.hidden = TRUE;
    
    [overlayView setAlpha:1.0 - slider.value];
}

- (IBAction)home{
    [self goHomeOrcancel];
}

- (void)goHomeOrcancel{
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:Nil
                                                      message:@"This will delete your current juxt-a-pose"
                                                     delegate:self
                                            cancelButtonTitle:@"Cancel"
                                            otherButtonTitles:@"Delete", nil];
    [message show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"Cancel"])
    {
    }
    else if([title isEqualToString:@"Delete"])
    {
        blendedImage = NULL;
         [self.navigationController popToRootViewControllerAnimated:NO];
    }
}

- (IBAction)cancelPhoto{

    if([firstPhoto isEqualToString:@"first"]){
        [[NSUserDefaults standardUserDefaults] setObject:@"firstCancel" forKey:@"base_photo"];
        [self dismissViewControllerAnimated:NO completion:NULL];
    }else if([firstPhoto isEqualToString:@"cancelUpload"]){
        [[NSUserDefaults standardUserDefaults] setObject:@"second" forKey:@"base_photo"];
        [self dismissViewControllerAnimated:NO completion:NULL];
    }else{
[self dismissViewControllerAnimated:YES completion:NULL];
    }
}


- (IBAction)shoot{
    
    adjustTran.hidden = TRUE;
    
    [picker takePicture];
}


- (IBAction)TakePhoto{
   
    [self startCam];
   
}

- (IBAction)ifClicked{
    clickTimes++;
    if (clickTimes == 3){
        clickTimes = 0;
        clickBlink.alpha = 0.2f;
        [UIView animateWithDuration:0.5f
                              delay:0.0f
                            options:UIViewAnimationOptionAutoreverse
                         animations:^
         {
             [UIView setAnimationRepeatCount:6.0f/3.0f];
             clickBlink.alpha = 1.0f;
         }
                         completion:^(BOOL finished)
         {

         }];
        
    }
}
- (IBAction)ifShootClicked{
    clickShootTimes ++;
    if (clickShootTimes == 3){
        clickShootTimes = 0;
        clickShootBlink.alpha = 0.2f;
        [UIView animateWithDuration:0.5f
                              delay:0.0f
                            options:UIViewAnimationOptionAutoreverse
                         animations:^
         {
             [UIView setAnimationRepeatCount:6.0f/3.0f];
             clickShootBlink.alpha = 1.0f;
         }
                         completion:^(BOOL finished)
         {
             
         }];
        
    }
}

-(void) startCam{
    
    NSString *flag = [[NSUserDefaults standardUserDefaults] stringForKey:@"not_first_run"];
    if(!flag){
        if([firstPhoto isEqualToString:@"first"]){
          tutShoot.hidden = FALSE;  
        }else if([firstPhoto isEqualToString:@"second"]){
            tutShoot.hidden = TRUE;
            adjustTran.hidden = FALSE;
            addAnother.hidden = FALSE;
            another.hidden = TRUE;
        }else if([firstPhoto isEqualToString:@"third"]){
            tutShoot.hidden = TRUE;
            adjustTran.hidden = TRUE;
            addAnother.hidden = FALSE;
            saveIt.hidden = FALSE;
            another.hidden = TRUE;
        }
    }else{
        another.hidden = FALSE;
        tutShoot.hidden = TRUE;
        adjustTran.hidden = TRUE;
        addAnother.hidden = TRUE;
    }
        
        
    picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    
    newImage=[[UIImageView alloc] init];
    newImage.image=blendedImage;
    
    [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
    picker.showsCameraControls = NO;
    picker.navigationBarHidden = YES;
    picker.toolbarHidden = YES;
    picker.allowsEditing = NO;
    
    if ([firstPhoto isEqual: @"first"]) {
         [self presentViewController:picker animated:NO completion:NULL];
    }else if ([uploadPhoto isEqual: @"cancelUpload"]) {
        [self presentViewController:picker animated:NO completion:NULL];
    }else{
         [self presentViewController:picker animated:YES completion:NULL];
    }

    
    
    [self OverlayImageOnTop];
    
}


- (void) OverlayImageOnTop{
    picker.showsCameraControls = NO;
    
    if([[UIScreen mainScreen] bounds].size.height == 568)
    {
        // iPhone 5
        overlayView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 106, 300, 300)];
        slider = [[UISlider alloc] initWithFrame:CGRectMake(33, 419, 254, 16)];
    }
    else
    {
        overlayView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 55, 300, 300)];
        slider = [[UISlider alloc] initWithFrame:CGRectMake(33, 364, 254, 16)];
    }
    
    UIImage *minImage = [[UIImage imageNamed:@"sliderbgMax.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:5];
    UIImage *maxImage = [[UIImage imageNamed:@"sliderbgMin.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:5];
    UIImage *thumbImage = [UIImage imageNamed:@"sliderThumb.png"];
    UIImageView *thumbButton = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 15, 15)];
    [thumbButton setImage: thumbImage];
    [[UISlider appearance] setMaximumTrackImage:maxImage forState:UIControlStateNormal];
    [[UISlider appearance] setMinimumTrackImage:minImage forState:UIControlStateNormal];
    [[UISlider appearance] setThumbImage:thumbButton.image forState:UIControlStateNormal];
    [[UISlider appearance] setThumbImage:thumbButton.image forState:UIControlStateHighlighted];
    [[UISlider appearance] setThumbImage:thumbButton.image forState:UIControlStateSelected];
    [slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    slider.minimumValue = 0.05;
    slider.maximumValue = 0.95;
    slider.continuous = YES;
    
    slider.value = 0.5;
    if ([firstPhoto isEqual: @"first"]) {
        slider.hidden = TRUE;
        transparent.hidden = TRUE;
        opaque.hidden = TRUE;
    }else if ([firstPhoto isEqual: @"new"]) {
        slider.hidden = TRUE;
        transparent.hidden = TRUE;
        opaque.hidden = TRUE;
    }else{
        slider.hidden = FALSE;
        transparent.hidden = FALSE;
        opaque.hidden = FALSE;
    }
    UIView *pickerView = picker.view;
        [overlayView setImage: imageView.image];
        [overlayView setContentMode:UIViewContentModeScaleToFill];
    realOverlayView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, pickerView.bounds.size.width, pickerView.bounds.size.height)];
    [realOverlayView addSubview:overlayView];
    [realOverlayView insertSubview:camBG aboveSubview:overlayView];
    [overlayView setAlpha:.5];
    [realOverlayView insertSubview:slider aboveSubview:camBG];
    
    picker.cameraOverlayView = realOverlayView;
    
    flashStatus = [[NSUserDefaults standardUserDefaults] stringForKey:@"flash_mode"];
    if([flashStatus isEqualToString: @"flashAuto"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeAuto];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashAuto.png"] forState:UIControlStateNormal];
    }else if([flashStatus isEqualToString: @"flashOn"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOn];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOn.png"] forState:UIControlStateNormal];
    }else if([flashStatus isEqualToString: @"flashOff"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOff];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOff.png"] forState:UIControlStateNormal];
    }
}

- (IBAction)ChooseExisting{
    if([firstPhoto isEqualToString:@"first"]){
         [[NSUserDefaults standardUserDefaults] setObject:@"firstUpload" forKey:@"base_photo"];
    }else{
         [[NSUserDefaults standardUserDefaults] setObject:@"upload" forKey:@"base_photo"];
    }

     [self dismissViewControllerAnimated:NO completion:NULL];
}

- (void) imagePickerController:(UIImagePickerController *)pickers didFinishPickingMediaWithInfo:(NSDictionary *)info{
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
        [self scaleAndRotateImage:image];
}

- (void)scaleAndRotateImage:(UIImage *)rotatedImage
{

    int kMaxResolution = 640; // Or whatever
    
    CGImageRef imgRef = rotatedImage.CGImage;
    
    CGFloat width = CGImageGetWidth(imgRef);
    CGFloat height = CGImageGetHeight(imgRef);
    
    CGAffineTransform transform = CGAffineTransformIdentity;
    bounds = CGRectMake(0, 0, width, height);
    if (width >= kMaxResolution || height >= kMaxResolution) {
        CGFloat ratio = width/height;
        if (ratio < 1) {
            bounds.size.width = kMaxResolution;
            bounds.size.height = bounds.size.width / ratio;
        }
        else {
            bounds.size.height = kMaxResolution;
            bounds.size.width = bounds.size.height * ratio;
        }
    }
    
    
    
    CGFloat scaleRatio = bounds.size.width / width;
    CGSize imageSize = CGSizeMake(CGImageGetWidth(imgRef), CGImageGetHeight(imgRef));
    CGFloat boundHeight;
    UIImageOrientation orient = rotatedImage.imageOrientation;
    if(cameraRotation == 0){ //rear camera
    switch(orient) {
            
        case UIImageOrientationUp: //EXIF = 1
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationDown: //EXIF = 3
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformMakeTranslation(0.0, imageSize.height);
            transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
            break;
            
        case UIImageOrientationLeft: //EXIF = 6
            boundHeight = bounds.size.height;
            bounds.size.height = bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight: //EXIF = 8
            boundHeight = bounds.size.height;
            bounds.size.height =bounds.size.width;
            bounds.size.width = boundHeight;
            transform = CGAffineTransformScale(transform, 1.0, -1.0);
            transform = CGAffineTransformMakeTranslation(imageSize.height, 0.0);
            transform = CGAffineTransformRotate(transform, M_PI / 2.0);
            break;
            
        default:
            [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
            
    }
        UIGraphicsBeginImageContext(bounds.size);
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        
        if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
            CGContextScaleCTM(context, -scaleRatio, scaleRatio);
            CGContextTranslateCTM(context, -height, 0);
        }
        else {
            CGContextScaleCTM(context, scaleRatio, -scaleRatio);
            CGContextTranslateCTM(context, 0, -height);
        }
        
        
        CGContextConcatCTM(context, transform);
        
        CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
        imageCopy = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
    }else if(cameraRotation == 1){ //front camera
        switch(orient) {
                
            case UIImageOrientationUp: //EXIF = 1
                boundHeight = bounds.size.height;
                bounds.size.height = bounds.size.width;
                bounds.size.width = boundHeight;
                transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.height);
                transform = CGAffineTransformScale(transform, -1.0, 1.0);
                transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
                break;
          
            case UIImageOrientationDown: //EXIF = 3
                boundHeight = bounds.size.height;
                bounds.size.height = bounds.size.width;
                bounds.size.width = boundHeight;
                transform = CGAffineTransformMakeTranslation(imageSize.height, imageSize.height);
                transform = CGAffineTransformScale(transform, -1.0, 1.0);
                transform = CGAffineTransformRotate(transform, 3.0 * M_PI / 2.0);
                break;
                
            case UIImageOrientationLeft: //EXIF = 6 orientation is ok but size is off
                boundHeight = bounds.size.height;
                bounds.size.height = bounds.size.width;
                bounds.size.width = boundHeight;
                transform = CGAffineTransformMakeScale(-1.0, 1.0);
                transform = CGAffineTransformRotate(transform, M_PI_2);
                break;
                
            case UIImageOrientationRight: //EXIF = 8 orientation is good size is off
                boundHeight = bounds.size.height;
                bounds.size.height = bounds.size.width;
                bounds.size.width = boundHeight;
                transform = CGAffineTransformMakeScale(-1.0, 1.0);
                transform = CGAffineTransformRotate(transform, M_PI_2);
                break;
                
            default:
                [NSException raise:NSInternalInconsistencyException format:@"Invalid image orientation"];
                
        }
        
        
        UIGraphicsBeginImageContext(bounds.size);
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        
        if (orient == UIImageOrientationRight || orient == UIImageOrientationLeft) {
            CGContextScaleCTM(context, -scaleRatio, scaleRatio);
            CGContextTranslateCTM(context, -height, 0);
        }
        else {
            CGContextScaleCTM(context, scaleRatio, -scaleRatio);
            CGContextTranslateCTM(context, 0, -height);
        }
        
        
        CGContextConcatCTM(context, transform);
        
        CGContextDrawImage(UIGraphicsGetCurrentContext(), CGRectMake(0, 0, width, height), imgRef);
        imageCopy = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    
    
   
    
    [self previewImage:imageCopy];
    //return imageCopy;
}

- (void)previewImage: (UIImage *)imagePreview{

    previewView.tag = 7;
    [realOverlayView insertSubview:previewView aboveSubview:slider];
    takenPhoto = imagePreview;
    if ([firstPhoto isEqual: @"first"]) {
        [previewImage setAlpha:1.0];
    }else if([firstPhoto isEqual: @"new"]) {
        [previewImage setAlpha:1.0];
    }else{
        overlayAlpha = overlayView.alpha;
        [overlayView setAlpha:1.0];
        [previewImage setAlpha:slider.value];
        slider.hidden = TRUE;
        transparent.hidden = TRUE;
        opaque.hidden = TRUE;
        
    }
        
    [previewImage setImage:imagePreview];
}

-(IBAction)cancelPreview{
    [overlayView setAlpha: overlayAlpha];
    NSString *flag = [[NSUserDefaults standardUserDefaults] stringForKey:@"base_photo"];
    if ([flag isEqualToString:@"first"]) {
        slider.hidden = TRUE;
        transparent.hidden = TRUE;
        opaque.hidden = TRUE;
    }else{
        slider.hidden = FALSE;
        transparent.hidden = FALSE;
        opaque.hidden = FALSE;
    }
    
            [previewView removeFromSuperview];
            

}

-(IBAction)usePhoto{

    cameraRotation = 0;
    if([firstPhoto isEqualToString:@"second"]){
    [[NSUserDefaults standardUserDefaults] setObject:@"third" forKey:@"base_photo"];
    }else if([firstPhoto isEqualToString:@"first"]){
        [[NSUserDefaults standardUserDefaults] setObject:@"second" forKey:@"base_photo"];
    }
    [self setRotatedImage:takenPhoto];
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (void)setRotatedImage:(UIImage *)rotatedImage{
    
    UIImage *imageSmall = rotatedImage;
    if([[UIScreen mainScreen] bounds].size.height == 568)
    {
        // iPhone 5
        img = [self cropImage:imageSmall andFrame:CGRectMake(48, 190, 543, 543)];
    }
    else
    {
        img = [self cropImage:imageSmall andFrame:CGRectMake(18, 110, 600, 600)];
    }
    
    UIImageView* bottomView = [[UIImageView alloc] initWithImage:img];
    topView = [[UIImageView alloc] initWithImage:newImage.image];
    [topView setAlpha:1.0 - slider.value];
    [bottomView addSubview:topView];
    UIGraphicsBeginImageContext(bottomView.frame.size);
    [bottomView.layer renderInContext:UIGraphicsGetCurrentContext()];
    blendedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    firstPhoto = @"anotherPhoto";
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return NO;
}

- (UIImage *)cropImage:(UIImage*)cropped andFrame:(CGRect)rect {
    
    
    rect = CGRectMake(rect.origin.x*cropped.scale,
                      rect.origin.y*cropped.scale,
                      rect.size.width*cropped.scale,
                      rect.size.height*cropped.scale);
    
    CGImageRef imageRef = CGImageCreateWithImageInRect([cropped CGImage], rect);
    UIImage *result = [UIImage imageWithCGImage:imageRef
                                          scale:cropped.scale
                                    orientation:cropped.imageOrientation];
    CGImageRelease(imageRef);
    return result;
}

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (void)viewDidAppear:(BOOL)animated{
    
    clickTimes = 0;
    clickShootTimes = 0;
    
    flashStatus = [[NSUserDefaults standardUserDefaults] stringForKey:@"flash_mode"];
    if([flashStatus isEqualToString: @"flashAuto"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeAuto];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashAuto.png"] forState:UIControlStateNormal];
    }else if([flashStatus isEqualToString: @"flashOn"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOn];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOn.png"] forState:UIControlStateNormal];
    }else if([flashStatus isEqualToString: @"flashOff"]){
        [picker setCameraFlashMode:UIImagePickerControllerCameraFlashModeOff];
        [toggleFlashMode setBackgroundImage:[UIImage imageNamed:@"flashOff.png"] forState:UIControlStateNormal];
    }
    
    another.alpha = 0.2f;
    [UIView animateWithDuration:0.5f
                          delay:0.0f
                        options:UIViewAnimationOptionAutoreverse
                     animations:^
     {
         [UIView setAnimationRepeatCount:6.0f/3.0f];
         another.alpha = 1.0f;
     }
                     completion:^(BOOL finished)
     {
     }];
    
    [imageView setImage:blendedImage];
    imageView.alpha = 0.0f;
    [UIView animateWithDuration:0.5f
                          delay:0.0f
                        options:UIViewAnimationOptionAllowAnimatedContent
                     animations:^
     {
         imageView.alpha = 1.0f;
     }
                     completion:^(BOOL finished)
     {
     }];
    
    firstPhoto = [[NSUserDefaults standardUserDefaults] stringForKey:@"base_photo"];
    
    if ([firstPhoto isEqualToString:@"first"]){
        [self startCam];
    }else if([firstPhoto isEqual: @"second"]) {
        NSString *flag = [[NSUserDefaults standardUserDefaults] stringForKey:@"not_first_run"];
        if(!flag){
                addAnother.hidden = FALSE;
                another.hidden = TRUE;
        }
            saveCover.hidden = FALSE;
    }else if([firstPhoto isEqual: @"third"]) {
        NSString *flag = [[NSUserDefaults standardUserDefaults] stringForKey:@"not_first_run"];
        if(!flag){
            saveIt.hidden = FALSE;
            addAnother.hidden = FALSE;
            another.hidden = TRUE;
            saveCover.hidden = TRUE;
        }else{
         saveCover.hidden = TRUE;    
        }
       
    }else if ([firstPhoto isEqualToString: @"upload"]){
        NSString *flag = [[NSUserDefaults standardUserDefaults] stringForKey:@"not_first_run"];
        if(!flag){
            addAnother.hidden = FALSE;
            saveIt.hidden = FALSE;
            another.hidden = TRUE;
        }
        PhotoLibrary *library = [[PhotoLibrary alloc] initWithNibName:@"PhotoLibrary" bundle:nil];
        [self presentViewController:library animated:NO completion:NULL];
    }else if ([firstPhoto isEqualToString: @"firstUpload"]){
        PhotoLibrary *library = [[PhotoLibrary alloc] initWithNibName:@"PhotoLibrary" bundle:nil];
        [self presentViewController:library animated:NO completion:NULL];
    }else if ([firstPhoto isEqualToString: @"cancelUpload"]){
        [self startCam];
        [[NSUserDefaults standardUserDefaults] setObject:@"second" forKey:@"base_photo"];
    }else if ([firstPhoto isEqualToString: @"firstCancel"]){
        [self.navigationController popToRootViewControllerAnimated:NO];
    }else{
        saveCover.hidden = TRUE;
    }
}



- (void)loadView
{
    if([[UIScreen mainScreen] bounds].size.height == 568)
    {
        // iPhone 5
        self.view = [[NSBundle mainBundle] loadNibNamed:@"ViewController" owner:self options:nil][0];
    }
    else
    {
        self.view = [[NSBundle mainBundle] loadNibNamed:@"ViewControllerFour" owner:self options:nil][0];
    }
}

- (void)viewDidLoad
{
    
    
    [super viewDidLoad];

    
    cameraRotation = 0;
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    tutShoot.hidden = TRUE;
    adjustTran.hidden = TRUE;
    addAnother.hidden = TRUE;
    saveIt.hidden = TRUE;
    another.hidden = FALSE;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
